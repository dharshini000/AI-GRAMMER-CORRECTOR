# AI Grammar and Sentence Corrector

A full-stack AI application that helps users correct grammatical errors and improve sentence structure in English.

## Features
- **Grammar Correction**: Corrects spelling, tense, and structure using NLP.
- **User-Friendly Interface**: Clean and responsive UI with instant feedback.
- **API-Based**: Decoupled frontend and backend using REST API.

## Project Structure
- `run.py`: Entry point for the application.
- `backend/`: Contains Flask app, grammar model, and utility functions.
- `frontend/`: Contains HTML templates, CSS styles, and JavaScript.
- `model/`: Stores the pickled grammar model.
- `dataset/`: Placeholder for training data.
- `requirements.txt`: Project dependencies.

## Setup and Usage

1. **Install Dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

2. **Run the Application**:
   ```bash
   python run.py
   ```
   The application will start at `http://127.0.0.1:5000`.

3. **Verify**:
   You can run the included test script to verify the backend:
   ```bash
   python test_backend.py
   ```

## Technologies
- Python, Flask
- HTML, CSS, JavaScript
- TextBlob (NLP)
