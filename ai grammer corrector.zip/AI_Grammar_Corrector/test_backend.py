import requests
import json
import time
import subprocess
import sys
import os

def test_api():
    # Start the server in the background
    print("Starting server...")
    server_process = subprocess.Popen([sys.executable, 'run.py'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(8)  # Wait longer for possible LanguageTool download/init

    url = 'http://127.0.0.1:5000/api/correct'
    
    test_cases = [
        ("my name was dharshini", "My name is Dharshini"), # Note: Might be "My name was..." or "My name is...", LT is context sensitive. Let's look for capitalization primarily.
        ("she go to college", "She goes to college"),
        ("i has a apple", "I have an apple")
    ]
    
    try:
        for input_text, expected_fragment in test_cases:
            print(f"\nTesting: '{input_text}'")
            response = requests.post(url, json={'text': input_text})
            
            if response.status_code == 200:
                result = response.json()
                corrected = result.get('corrected', '')
                print(f"Output: '{corrected}'")
                
                # Check for key improvements
                if corrected != input_text:
                    print("PASS: Output changed.")
                else:
                    print("FAIL: Output same as input.")
            else:
                print(f"FAIL: Status {response.status_code}")
                print(response.text)

    except Exception as e:
        print(f"\nAPI Test Error: {e}")
    finally:
        # Kill the server
        print("Stopping server...")
        server_process.terminate()
        try:
            server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server_process.kill()
        print("Server stopped.")

if __name__ == "__main__":
    test_api()
