document.addEventListener('DOMContentLoaded', () => {
    const inputText = document.getElementById('inputText');
    const checkBtn = document.getElementById('checkBtn');
    const clearBtn = document.getElementById('clearBtn');
    const outputContainer = document.getElementById('outputContainer');
    const loading = document.getElementById('loading');

    checkBtn.addEventListener('click', async () => {
        const text = inputText.value.trim();

        if (!text) {
            outputContainer.innerHTML = '<p class="error-msg" style="color: var(--error-color);">Please enter some text to check.</p>';
            return;
        }

        // Show loading state
        loading.classList.remove('hidden');
        outputContainer.innerHTML = ''; // Clear previous output
        checkBtn.disabled = true;

        try {
            const response = await fetch('/api/correct', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ text: text })
            });

            const data = await response.json();

            if (response.ok) {
                if (data.corrected) {
                    outputContainer.innerHTML = `<div class="corrected-text">${data.corrected}</div>`;
                } else {
                    outputContainer.innerHTML = '<p class="placeholder-text">No corrections needed or empty result.</p>';
                }
            } else {
                outputContainer.innerHTML = `<p class="error-msg" style="color: red;">Error: ${data.error || 'Something went wrong.'}</p>`;
            }

        } catch (error) {
            console.error('Error:', error);
            outputContainer.innerHTML = '<p class="error-msg" style="color: red;">Failed to connect to the server.</p>';
        } finally {
            loading.classList.add('hidden');
            checkBtn.disabled = false;
        }
    });

    clearBtn.addEventListener('click', () => {
        inputText.value = '';
        outputContainer.innerHTML = '<p class="placeholder-text">Your corrected text will appear here.</p>';
        inputText.focus();
    });
});
