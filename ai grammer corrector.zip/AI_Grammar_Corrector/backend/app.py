from flask import Flask, render_template, request, jsonify
import os
from backend.grammar_model import load_model, GrammarModel
from backend.utils import preprocess_text, postprocess_text

app = Flask(__name__, template_folder='../frontend/templates', static_folder='../frontend/static')

# Load the model
try:
    model_path = os.path.join(os.getcwd(), 'model', 'grammar_model.pkl')
    model = load_model(model_path)
except Exception as e:
    print(f"Failed to load model: {e}")
    # Fallback to a fresh instance if loading fails completely
    model = GrammarModel()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/correct', methods=['POST'])
def correct_grammar():
    data = request.get_json()
    if not data or 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400
    
    text = data['text']
    if not text.strip():
        return jsonify({'corrected': ''})

    # Preprocess
    clean_text = preprocess_text(text)
    
    # Correct using the model
    corrected_text = model.correct(clean_text)
    
    # Postprocess
    final_text = postprocess_text(text, corrected_text)
    
    return jsonify({'corrected': final_text})

if __name__ == '__main__':
    app.run(debug=True)
