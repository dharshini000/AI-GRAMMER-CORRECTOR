import pickle
import os
import language_tool_python

class GrammarModel:
    def __init__(self):
        self.model_name = "LanguageTool-based Grammar Corrector"
        # We don't pickle the tool object itself as it maintains a process connection
        self.tool = None

    def _ensure_tool(self):
        """
        Ensures the LanguageTool instance is ready.
        """
        if self.tool is None:
            print("Initializing LanguageTool...")
            self.tool = language_tool_python.LanguageTool('en-US')

    def correct(self, text):
        """
        Corrects the grammar and spelling of the input text using LanguageTool.
        """
        if not text:
            return ""
        
        self._ensure_tool()
        
        # language-tool-python provides a correct() method that applies suggestions
        corrected_text = self.tool.correct(text)
        return corrected_text
    
    
    def __getstate__(self):
        """
        Custom pickling state: exclude the 'tool' object.
        """
        state = self.__dict__.copy()
        state['tool'] = None
        return state

    def __setstate__(self, state):
        """
        Restore state and ensure 'tool' attribute is present.
        """
        self.__dict__.update(state)
        if 'tool' not in self.__dict__:
            self.tool = None

def load_model(model_path):
    """
    Loads the model from the specified path.
    If the model file doesn't exist or is invalid, creates a new one and saves it.
    """
    if os.path.exists(model_path):
        try:
            with open(model_path, 'rb') as f:
                model = pickle.load(f)
            print(f"Model loaded from {model_path}")
            return model
        except Exception as e:
            print(f"Error loading model: {e}. Creating a new one.")
    
    # Create and save a new model if loading fails
    model = GrammarModel()
    save_model(model, model_path)
    return model

def save_model(model, model_path):
    """
    Saves the model to the specified path.
    """
    try:
        os.makedirs(os.path.dirname(model_path), exist_ok=True)
        with open(model_path, 'wb') as f:
            pickle.dump(model, f)
        print(f"Model saved to {model_path}")
    except Exception as e:
        print(f"Error saving model: {e}")

# For testing/initialization
if __name__ == "__main__":
    # Determine correct path relative to script execution
    # If run from root (python backend/grammar_model.py) or (python run.py)
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    model_path = os.path.join(base_dir, 'model', 'grammar_model.pkl')
    
    print(f"Target model path: {model_path}")

    model = GrammarModel()
    # Pre-warm the tool download if needed
    model._ensure_tool() 
    
    save_model(model, model_path)
    print("Model initialized and saved.")
