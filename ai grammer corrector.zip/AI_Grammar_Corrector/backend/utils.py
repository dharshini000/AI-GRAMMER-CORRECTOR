def preprocess_text(text):
    """
    Cleans and prepares the text for the model.
    """
    if not text:
        return ""
    # Basic cleaning: remove excessive whitespace
    return " ".join(text.split())

def postprocess_text(original, corrected):
    """
    Formats the corrected text for display.
    """
    # Simply return the corrected text for now. (Can add diff highlighting logic here later if needed by backend, 
    # but frontend is usually better for visual diffs)
    return corrected
